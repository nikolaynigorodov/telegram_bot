<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TelegramController extends Controller
{
    public function start()
    {
        $update = json_decode(file_get_contents('php://input'));
        file_put_contents('test.txt', $update, FILE_APPEND);
        //https://api.telegram.org/bot5866281254:AAGD50ZLxeNY2cJHm9hIkLSovCDEyTK8XAo/setwebhook?url=https://test-yellow-duck.pp.ua/telegram
        //GroupId = -864428091
        //botId = 599442977
        //https://api.telegram.org/bot5866281254:AAGD50ZLxeNY2cJHm9hIkLSovCDEyTK8XAo/getUpdates - узнать id
    }
}
