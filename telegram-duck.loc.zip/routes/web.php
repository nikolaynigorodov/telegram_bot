<?php

use App\Http\Controllers\TelegramController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

/*Route::any('/telegram', [TelegramController::class, 'start'])->name('start');*/
/*Route::get('/', function () {
    \Illuminate\Support\Facades\Http::post('https://api.tlgr.org/bot5866281254:AAGD50ZLxeNY2cJHm9hIkLSovCDEyTK8XAo/sendMessage', [
        'chat_id' => -864428091,
        'text' => 'Hello'
    ]);
});*/

Route::post('/telegram-webhook', \App\Http\Controllers\TelegramWebHookController::class)
    ->name('telegram.webhook');
